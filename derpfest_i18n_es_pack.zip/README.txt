DerpFest Spanish (es) i18n pack — drop-in files
===============================================
This archive contains:
1) android_packages_apps_DerpFestCustomizations/res/values-b+es/strings.xml
   android_packages_apps_DerpFestCustomizations/res/values-es/strings.xml
   → Spanish strings for DerpFest Customizations (A16).
   → Keep BOTH folders for maximum compatibility with different build setups.

2) android_packages_apps_Settings/res/values-es/derp_additions_strings.xml
   → Spanish strings matching tiles seen in screenshots:
     - Digital Wellbeing & parental controls (dashboard title/summary)
     - Enable blurs (title/summary)
     - Screen refresh rate (title)
     - Enhanced HDR brightness (title/summary)
     - Full screen apps (title/summary)

How to contribute via PR (web flow):
- Open your fork for each repo on GitHub (branch '16').
- Create the folders as above and upload the files.
- Commit on a new branch, then open a Pull Request against DerpFest-AOSP '16' branch.
- PR title example: "Add Spanish (es) translations for Customizations and Settings tiles [A16]"
- In the PR body, mention: placeholders preserved, valid XML, CLDR plural rules when applicable.

Notes:
- The Settings keys are a best-effort mapping for common derivatives used by custom ROMs;
  keepers may rename or adjust during review. If they prefer Crowdin/Weblate, they will redirect.
